import { likeAlreadyExistsError } from '../../services/errorService.js';
import insertLikeModel from '../../models/reels/insertLikeModel.js';
import selectReelByIdModel from '../../models/reels/selectReelByIdModel.js';

const likeReelController = async (req, res, next) => {
    try {
        const { reelId } = req.params;
        const { value } = req.body;

        const reel = await selectReelByIdModel(reelId);

        // el dueño del reel no puede dar like a su propio reel
        if(reel.userId === req.user.id) likeAlreadyExistsError();

        const likesAvg = await insertLikeModel(value, reelId, req.user.id);

        res.send({
            status: 'ok',
            data: likesAvg,
            message: 'Like OK ❤️'
        });
    } catch (error) {
        if (error.name === 'SequelizeUniqueConstraintError') {
            likeAlreadyExistsError();
        } else {
            next(error);
        }
    }
};

export default likeReelController;