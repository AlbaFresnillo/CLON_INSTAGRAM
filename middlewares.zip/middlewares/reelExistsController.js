import selectReelByIdModel from '../models/reels/selectReelByIdModel.js';

const reelExistsController = async (req, res, next) => {
    try {
        const {reelId} = req.params;

        const reel = await selectReelByIdModel(reelId);

        if (!reel) {
            return res.status(404).send({
                status: 'fail',
                message: 'Reel not found'
            });
        }

        req.reel= reel;
        req.reelUserId = reel.userId;
        next();
    
    } catch (error) {
        next(error);
    }
}

export default reelExistsController;