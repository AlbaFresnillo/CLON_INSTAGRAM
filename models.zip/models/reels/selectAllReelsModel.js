import getPool from "../../db/getPool.js";

const selectAllReelsModel = async () => {

    const pool = await getPool();

       const [reels] = await pool.query (`
                SELECT r.id, 
                        r.text,
                        u.username,
                        SUM(IFNULL(v.value,0)) AS likes,
                        r.createdAt
                FROM reels r
                LEFT JOIN likes l ON l.reelId = r.id
                INNER JOIN users u ON u.id = r.userId
                GROUP BY r.id
                ORDER BY r.createdAt DESC  `
        );

        for(const reel of reels){
            const [photos] = await pool.query(
                `
                    SELECT id, name FROM reelphotos WHERE reelId = ?
                `,
                [reel.id]
            );
            
            //creo una nueva clave al objeto dentro del array
            reel.photos = photos
        }
    
        return reels;
    };
    
    export default selectAllReelsModel;