import getPool from "../../db/getPool.js";
import { likeAlreadyExistsError } from "../../services/errorService.js";

const insertLikeModel = async (value, reelId, userId) => {
    const pool = await getPool();

    try {
        // Comprobar que si existe un like previo por parte del usuario para ese reel, no pueda darle de nuevo
        const [likes] = await pool.query(
            `
            SELECT id FROM likes
            WHERE userId = ? AND reelId = ?
            `,
            [userId, reelId]
        );

        if (likes.length > 0 ) {
            likeAlreadyExistsError();
        }

 // Insertamos el like en likes (valor 1 o -1)
 await pool.query(
    `
    INSERT INTO likes (id, reelId, userId, value)
    VALUES (?, ?, ?,?)
    `,
    [uuid(), reelId, userId, value]
);

        // Obtenemos la suma total actualizada de likes del reel y el total de likes
        const [likesInfo] = await pool.query(
            `
            SELECT SUM(value) AS likesSum, COUNT(*) AS total_likes
            FROM likes
            WHERE reelId = ?
            `,
            [reelId]
        );

        const { likesSum, total_likes } = likesInfo[0];

        // Actualiza el contador de likes para el reel especificado
        await pool.query(
            `
            UPDATE reels
            SET likesSum = ?
            WHERE id = ?
            `,
            [likesSum, reelId]
        );

        // Retorna el total de likes
        return total_likes;


    // Otras acciones o retornos de la función según sea necesario
} catch (error) {
    // Manejo de errores
    console.error('Error en insertLikeModel:', error);
}
};

export default insertLikeModel;